clear all; hfig = figure
%% Cac hang so don vi
c = 3e8; %m/s
e = 1.60219e-19;% C
meV = e*1e-3;
h=1.05459e-34;%J/s
kb=1.3807e-23;
epsilon0 = 8.86*10^(-12);%F/m
%% Tham so vat lieu GaAs va
xdata = linspace(0.3,0.3,1);
for idx = 1:length(xdata)
x =xdata(idx);% nong do nhom
m=0.067*9.1*10^(-31);% khoi luong hieu dung cua dien tu GaAs
ne=3e16*10^9; % nong do hat tai 
Ldata = linspace(10,20,30);
for kk = 1:length(Ldata)
    Lnm = Ldata(kk); %nm
    Lm = Lnm/1e9; %m
    S = Lm^2; % dien tich cua mau
    kappai = 10.89-2.73*x;
    kappa0 = 13.18-3.12*x;
    kappa = 1/kappai - 1/kappa0;
    a0 = 7.5*10^(-9);%m
    %% Tham so the morse
    U0meV = 0.6 * (1155*x + 370*x^2);% do cao gieng the meV
    U0J = U0meV*meV;%J
    homegaq = 36.25*meV;
    omegaq = homegaq/h;
    lambda = sqrt(2*m*Lm^2*U0J/h^2);
    %% Tham so song dien tu manh va moi truong
    E0 = 1e5;% V/m
    Bdata = [10];% tham so tu truong deu T
    T = 77;%K
    %% mien khao sat
    hOmega = (5:0.01:160) *meV; %J
    Omega = hOmega/h; %s
    %% ham song theo phuong giam giu cua ho the
    dz = 0.1;
    znm = -100:dz:100;%nm
    zm = znm/1e9; %m
    eta = znm/Lnm;
    csi = 2*lambda*exp(-eta);
    homegaz = sqrt(2*h^2*U0J/(m*S));
    for nn = 0:1:1
        j = lambda-nn-1/2;
        An = (2*j*gamma(nn+1)/gamma(2*lambda-nn))^0.5;% he so chuan hoa cua the morse
        phi_n(nn+1,:)=An*csi.^j.*exp(-csi/2).*laguerreL(nn,2*j,csi);
    end
    %% Tinh tich phan Gnnp
    n = 0;
    np = 1;
    % ans = integral(Innp,z,[-40,100])
    % de tinh tich phan theo z ta tinh so phi_n exp(iqz z) phi_np voi tung gia
    % tri cua qz trong mien qz (ta tu lay). Do do can phai kiem tra bien cua qz
    % xem da thuc su hoi tu chua. De bien qua rong thi lau ma de bien hep thi
    % tich phan khong chinh xac
    Gnnp = 0;
    dqz = 0.1;
    for qz = 0:dqz:40
        Innp = sum(phi_n(n+1,:).*phi_n(np+1,:).*exp(1i*qz*znm))*dz*Lnm;
        add = abs(Innp)^2*dqz;
        Gnnp = Gnnp+ add; 
    end
    Gnnpk(kk)=Gnnp;
    Gnnp=Gnnp;
    %% Xet 1 qua trinh chuyen dich tu nN = 00 len np Np = 11 cua cong suat hap thu
    % cac muc chuyen dich
    n = 0;
    N = 0;
    np = 1;
    Np = 1;
    %%%---------------------------------Ham phan bo bolztmann------------------
    for id = 1:length(Bdata)
        B = Bdata(id);
        lb = sqrt(h/(e*B));
        omegab = e*B/m;
        homegab = omegab*h;
        MSFnN = 0;% mau so trong ham phan bo bolztmann.
        epsilon_n_N = (N+1)*homegab + ((n+1/2)-1/(2*lambda)*(n+1/2)^2)*homegaz;
        for nid = 0:1
        for Nid = 0:1
            epsilon_Nid = (Nid+1/2)*homegab;% nang luong theo tu truong
            epsilon_nid = ((nid+1/2)-1/(2*lambda)*(n+1/2)^2)*homegaz; % nang luong theo ho 
            epsilon_nid_Nid = epsilon_nid + epsilon_Nid;
            MSFnN = MSFnN + exp(-epsilon_nid_Nid/(kb*T)); 
        end
        end
        Fi = exp(-epsilon_n_N/(kb*T))/MSFnN;% day la ham phan bo maxwell bolztmann(thanh phan hang
        % so da bi tach ra vao truoc do) chinh la cai Gamma (mai nha)
        %--------------------------------------------------------------------------
        % thanh phan hang so truoc cong suat hap thu
        delta_Nm1_Np = 0 ;% delta dirac cua N-1,Np
        delta_Np1_Np = 1 ;% delta dirac cua N+1,Np
        P0 = E0^4*(kappa0)^0.5*ne*e^4*homegaq*a0^2*(S/Lnm^2)^2./Lm./(128*pi^4*lb^4*epsilon0*kappa*h^2).*...
            Fi*Gnnp*...
            lb^2/2*(sqrt(N)*delta_Nm1_Np+sqrt(N+1)*delta_Np1_Np)/Gnnp^0.727% Q_N,N'%chia nay la de lay do cao dinh
    %     P0 = E0^4*(kappa0)^0.5*e^4*ne*omegaq*a0^2*Lm*S^2./(128*epsilon0*kappa*pi^3*lb^4*h^2*Omega.^2).*...
    %         Fi*Gnnp*...
    %         lb^2/2*(sqrt(N)*delta_Nm1_Np+sqrt(N+1)*delta_Np1_Np);
        %%------------------------- Thanh phan tao dinh cho pho hap thu------------
Co(kk)=P0;
    end
end

end
% find(Ldata,Co)
plot(Ldata,Co)
xlabel("L (nm)");
ylabel("\mathcal{D} (arb. units)")
% text(locs+.02,pks,num2str((1:numel(pks))'))