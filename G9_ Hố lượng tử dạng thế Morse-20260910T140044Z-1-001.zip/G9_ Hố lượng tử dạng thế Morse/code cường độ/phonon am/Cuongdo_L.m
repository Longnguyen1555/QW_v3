clear all; 
%% Cac hang so don vi
c = 3e8; %m/s
e = 1.60219e-19;% C
meV = e*1e-3;
h=1.05459e-34;%J/s
kb=1.3807e-23;
epsilon0 = 8.86*10^(-12);%F/m
%% Tham so vat lieu GaAs va
x =0.3;% nong do nhom
m=0.067*9.1*10^(-31);% khoi luong hieu dung cua dien tu GaAs
ne=3e16*10^9; % nong do hat tai
Ldata = linspace(8,20,20);
for ii = 1:length(Ldata)
Lnm = Ldata(ii); %nm
Lm = Lnm/1e9; %m
S = Lm^2; % dien tich cua mau
kappai = 10.89-2.73*x;%kappa vo cunng
kappa0 = 13.18-3.12*x;%kappa 0
kappa = 1/kappai - 1/kappa0;
a0 = 7.5*10^(-9);%m
%% Tham so the morse
U0meV = 0.6 * (1155*x + 370*x^2);% do cao gieng the meV
U0J = U0meV*meV;%J
homegaq = 36.25*meV;
omegaq = homegaq/h;
lambda = sqrt(2*m*Lm^2*U0J/h^2);
%% can check
Dac = 13.5*e;%J
rho = 5320;%kg/m^3
vs =5378;%m/s
%% Tham so song dien tu manh va moi truong
E0 = 1e5;% V/m
B = 10;% tham so tu truong deu T
lb = sqrt(h/(e*B));
omegab = e*B/m;
homegab = omegab*h;
T = 5;%K
%% mien khao sat
hOmega = (20:0.01:110) *meV; %J
Omega = hOmega/h; %s
%% ham song theo phuong giam giu cua ho the
dz = 0.1;
znm = -100:dz:100;%nm
zm = znm/1e9; %m
eta = znm/Lnm;
csi = 2*lambda*exp(-eta);
homegaz = sqrt(2*h^2*U0J/(m*S))
for nn = 0:1:1
    j = lambda-nn-1/2;
    An = (2*j*gamma(nn+1)/gamma(2*lambda-nn))^0.5;% he so chuan hoa cua the morse
    phi_n(nn+1,:)=An*csi.^j.*exp(-csi/2).*laguerreL(nn,2*j,csi);% phi_n la symbolic theo z
%     Norm = sum(phi_n(nn+1,:).*phi_n(nn+1,:))*dz;
%     phi_n(nn+1,:) =phi_n(nn+1,:).*(1/Norm)^0.5; 
end
%% Tinh tich phan Gnnp
n = 0;
np = 1;
% ans = integral(Innp,z,[-40,100])
% de tinh tich phan theo z ta tinh so phi_n exp(iqz z) phi_np voi tung gia
% tri cua qz trong mien qz (ta tu lay). Do do can phai kiem tra bien cua qz
% xem da thuc su hoi tu chua. De bien qua rong thi lau ma de bien hep thi
% tich phan khong chinh xac
Gnnp = 0;
dqz = 0.1;
for qz = 0:dqz:40
    Innp = sum(phi_n(n+1,:).*phi_n(np+1,:).*exp(1i*qz*znm))*dz/Lnm;
    add = abs(Innp)^2*dqz;
    Gnnp = Gnnp+ add; 
end
Gnnp = Gnnp*1e10 %so 3000 la fake them vao de mo rong do rong vach pho
%% Xet 1 qua trinh chuyen dich tu nN = 00 len np Np = 11 cua cong suat hap thu
% cac muc chuyen dich
n = 0;
N = 0;
np = 1;
Np = 1;
%%%---------------------------------Ham phan bo bolztmann------------------
MSFnN = 0;% mau so trong ham phan bo bolztmann.
epsilon_n_N = (N+1)*homegab + ((n+1/2)-1/(2*lambda)*(n+1/2)^2)*homegaz;
for nid = 0:1
for Nid = 0:1
    epsilon_Nid = (Nid+1/2)*homegab;% nang luong theo tu truong
    epsilon_nid = ((nid+1/2)-1/(2*lambda)*(n+1/2)^2)*homegaz; % nang luong theo ho 
    epsilon_nid_Nid = epsilon_nid + epsilon_Nid;
    MSFnN = MSFnN + exp(-epsilon_nid_Nid/(kb*T)); 
end
end
Fi = exp(-epsilon_n_N/(kb*T))/MSFnN;% day la ham phan bo maxwell bolztmann(thanh phan hang
% so da bi tach ra vao truoc do) chinh la cai Gamma (mai nha)
%--------------------------------------------------------------------------
% thanh phan hang so truoc cong suat hap thu
delta_Nm1_Np = 0 ;% delta dirac cua N-1,Np
delta_Np1_Np = 1 ;% delta dirac cua N+1,Np
P0 = E0^4*e^2*(kappa0)^0.5*ne*Dac*kb*T.*a0^2./(512*pi^5*h*rho*vs^2*lb^6).*...
    Fi*Gnnp*...
    lb^2/2*(sqrt(N)*delta_Nm1_Np+sqrt(N+1)*delta_Np1_Np).*B^20/Lnm;% Q_N,N'
%%------------------------- Thanh phan tao dinh cho pho hap thu------------
Co(ii) = P0;
end
plot(Ldata,Co*1e-21);
% [pks,locs,width] = findpeaks(P,X,'Annotate','extents');
% findpeaks(P,X)
% text(locs-1,pks+5e-7,num2str((1:numel(pks))'))
xlabel('L')
ylabel('$\mathcal{D}$ (arab.units)')
% legend('$\ell=1$','$\ell=2$','$\ell=3$')