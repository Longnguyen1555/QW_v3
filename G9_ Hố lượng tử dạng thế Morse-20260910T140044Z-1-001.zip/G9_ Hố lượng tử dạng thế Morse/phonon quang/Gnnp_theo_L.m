clear all; 
%% Cac hang so don vi
c = 3e8; %m/s
e = 1.60219e-19;% C
meV = e*1e-3;
h=1.05459e-34;%J/s
kb=1.3807e-23;
epsilon0 = 8.86*10^(-12);%F/m
%% Tham so vat lieu GaAs va
x =0.3;% nong do nhom
m=0.067*9.1*10^(-31);% khoi luong hieu dung cua dien tu GaAs
ne=3e16*10^9; % nong do hat tai 
Ldata = 5:1:20;
for kk = 1:length(Ldata)
Lnm = Ldata(kk); %nm
Lm = Lnm/1e9; %m
S = Lm^2; % dien tich cua mau
kappai = 10.89-2.73*x;
kappa0 = 13.18-3.12*x;
kappa = 1/kappai - 1/kappa0;
a0 = 7.5*10^(-9);%m
%% Tham so the morse
U0meV = 0.6 * (1155*x + 370*x^2);% do cao gieng the meV
U0J = U0meV*meV;%J
homegaq = 36.25*meV;
omegaq = homegaq/h;
lambda = sqrt(2*m*Lm^2*U0J/h^2);
%% Tham so song dien tu manh va moi truong
E0 = 1e5;% V/m
Bdata = [3 6 9];% tham so tu truong deu T
T = 150;%K
%% mien khao sat
hOmega = (5:0.01:160) *meV; %J
Omega = hOmega/h; %s
%% ham song theo phuong giam giu cua ho the
dz = 0.1;
znm = -120:dz:120;%nm
zm = znm/1e9; %m
eta = znm/Lnm;
deta = dz/Lnm;
csi = 2*lambda*exp(-eta);
homegaz = sqrt(2*h^2*U0J/(m*S));
for nn = 0:1:1
    j = lambda-nn-1/2;
    An = (2*j*gamma(nn+1)/gamma(2*lambda-nn))^0.5;% he so chuan hoa cua the morse
    phi_n(nn+1,:)=An*csi.^j.*exp(-csi/2).*laguerreL(nn,2*j,csi);% phi_n la symbolic theo z
end
N=sum(phi_n(1,:).*phi_n(1,:))*dz/Lnm;
%% Tinh tich phan Gnnp
n = 0;
np = 1;
% ans = integral(Innp,z,[-40,100])
% de tinh tich phan theo z ta tinh so phi_n exp(iqz z) phi_np voi tung gia
% tri cua qz trong mien qz (ta tu lay). Do do can phai kiem tra bien cua qz
% xem da thuc su hoi tu chua. De bien qua rong thi lau ma de bien hep thi
% tich phan khong chinh xac
Gnnp = 0;
dqz = 0.1;
for qz = 0:dqz:60
    Innp = sum(phi_n(n+1,:).*phi_n(np+1,:).*exp(1i*qz*znm))*dz/Lnm;
    add = abs(Innp)^2*dqz;
    Gnnp = Gnnp+ add; 
end
f(kk) = Gnnp;
end
plot(Ldata,f)